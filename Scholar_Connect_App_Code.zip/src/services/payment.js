export async function makePayment(amount, phoneNumber) {
  const response = await fetch('/api/m-pesa', {
    method: 'POST',
    body: JSON.stringify({ amount, phoneNumber }),
  });

  return await response.json();
}