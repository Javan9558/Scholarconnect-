const API_URL = 'https://api.scholarconnect.com';

export async function fetchFromAPI(endpoint) {
  const response = await fetch(`${API_URL}/${endpoint}`);
  const data = await response.json();
  return data;
}