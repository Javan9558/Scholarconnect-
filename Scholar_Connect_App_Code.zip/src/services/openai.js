import { fetchFromAPI } from './api';

export async function askOpenAI(prompt) {
  const response = await fetchFromAPI(`openai?prompt=${prompt}`);
  return response.result;
}