import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to Scholar Connect</h1>
      <p>Your AI-powered study assistant</p>
    </div>
  );
};

export default Home;