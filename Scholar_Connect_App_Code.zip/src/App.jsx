import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import VirtualTutor from './pages/VirtualTutor';
import PeerTutoring from './pages/PeerTutoring';
import StudyResources from './pages/StudyResources';
import StudyGroup from './components/StudyGroup';
import SmartSearch from './components/SmartSearch';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/virtual-tutor" element={<VirtualTutor />} />
        <Route path="/peer-tutoring" element={<PeerTutoring />} />
        <Route path="/study-resources" element={<StudyResources />} />
        <Route path="/study-group" element={<StudyGroup />} />
        <Route path="/smart-search" element={<SmartSearch />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;